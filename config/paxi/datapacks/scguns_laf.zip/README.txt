All textures are copied from the Scorched Guns mod:
	On Curseforge: https://www.curseforge.com/minecraft/mc-mods/scorched-guns
	On github: https://github.com/ribs498/scorchedguns

All JSON assets are derived from both the Scorched Guns mod (see above) and the "Haywire Robots, Bandits and Guns- A Scorched Bronze Addon" mod:
	On Curseforge: https://www.curseforge.com/minecraft/mc-mods/haywire-robots-bandits-and-guns-a-scorched-bronze
	On github: https://github.com/ribs498/scguns